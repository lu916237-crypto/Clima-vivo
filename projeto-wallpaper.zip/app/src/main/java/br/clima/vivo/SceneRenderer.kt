package br.clima.vivo

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Paisagem do Clima vivo desenhada direto no Canvas (porte da versão web). */
class SceneRenderer {
    // tempo (suavizado até o alvo)
    private var cloud = 0.08f
    private var wind = 0.15f
    private var rain = 0f
    private var dark = 0f
    private var storm = 0f

    private var t = 0f
    private var sunT = 0.5f
    private val extras = SceneExtras()
    private var angle = 0f
    private var gw = 0f
    private var flash = 0f
    private var nextFlash = 2f
    private var lastBolt = -999f
    private var bolt: List<PointF>? = null
    private var smokeT = 0f
    private val smoke = ArrayList<FloatArray>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val starX = FloatArray(70) { Random.nextFloat() }
    private val starY = FloatArray(70) { Random.nextFloat() * 0.5f }
    private val starP = FloatArray(70) { Random.nextFloat() * 6f }
    private val dropX = FloatArray(280) { Random.nextFloat() }
    private val dropY = FloatArray(280) { Random.nextFloat() }
    private val dropV = FloatArray(280) { 0.9f + Random.nextFloat() * 0.6f }
    private val clouds = List(8) { i ->
        floatArrayOf(
            Random.nextFloat() * 1.3f - 0.15f,
            0.07f + ((i * 37) % 10) / 10f * 0.28f,
            0.7f + ((i * 53) % 10) / 10f * 0.9f,
            0.4f + ((i * 29) % 10) / 10f * 0.6f
        )
    }
    // 3 formas de nuvem x 3 cores (clara, escura, quente)
    private val sprites: List<Array<Bitmap>> = List(3) { sh ->
        arrayOf(
            makeCloud(sh, Color.rgb(176, 194, 220), Color.rgb(255, 255, 255)),
            makeCloud(sh, Color.rgb(48, 54, 68), Color.rgb(112, 120, 138)),
            makeCloud(sh, Color.rgb(206, 136, 120), Color.rgb(255, 222, 188))
        )
    }

    private fun makeCloud(sh: Int, lo: Int, hi: Int): Bitmap {
        val bm = Bitmap.createBitmap(300, 140, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bm)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val q = arrayOf(
            floatArrayOf(.16f, .66f, .15f), floatArrayOf(.30f, .50f, .20f), floatArrayOf(.50f, .40f, .23f),
            floatArrayOf(.70f, .50f, .20f), floatArrayOf(.86f, .66f, .14f), floatArrayOf(.50f, .68f, .20f)
        )
        val layers = listOf(Pair(lo, 0.10f), Pair(hi, -0.08f))
        for ((col, dy) in layers) {
            for ((i, pu) in q.withIndex()) {
                val px = (pu[0] + sin(sh * 3f + i) * 0.04f) * 300f
                val py = (pu[1] + cos(sh * 2f + i * 2f) * 0.05f + dy) * 140f
                val pr = pu[2] * (0.9f + 0.1f * ((sh + i) % 3)) * 210f
                p.shader = RadialGradient(
                    px, py, pr,
                    Color.argb(242, Color.red(col), Color.green(col), Color.blue(col)),
                    Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                    Shader.TileMode.CLAMP
                )
                cv.drawCircle(px, py, pr, p)
            }
        }
        return bm
    }

    private fun realHour(): Float {
        val c = Calendar.getInstance()
        return c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE) / 60f + c.get(Calendar.SECOND) / 3600f
    }

    fun draw(c: Canvas, w: Float, h: Float, estado: String, horaManual: Float, dtIn: Float, auto: FloatArray?) {
        val dt = min(dtIn, 0.1f)
        t += dt

        // alvo do tempo e suavização
        val tg = auto ?: when (estado) {
            "nublado" -> floatArrayOf(0.75f, 0.30f, 0.0f, 0.30f, 0f)
            "ventania" -> floatArrayOf(0.55f, 1.00f, 0.0f, 0.20f, 0f)
            "chuva" -> floatArrayOf(0.95f, 0.50f, 0.6f, 0.60f, 0f)
            "tempestade" -> floatArrayOf(1.00f, 0.90f, 1.0f, 0.95f, 1f)
            else -> floatArrayOf(0.08f, 0.15f, 0.0f, 0.00f, 0f)
        }
        val k = min(1f, dt * 1.2f)
        cloud += (tg[0] - cloud) * k
        wind += (tg[1] - wind) * k
        rain += (tg[2] - rain) * k
        dark += (tg[3] - dark) * k
        storm += (tg[4] - storm) * k

        val hour = if (horaManual >= 0f) horaManual else realHour()
        val night = if (hour < 12f) 1f - smooth(4.75f, 6.25f, hour) else smooth(18.25f, 19.75f, hour)
        val warm = clamp01(exp(-sq((hour - 19f) / 0.8f)) + exp(-sq((hour - 5.5f) / 0.8f)))
        val dk = 1f - (1f - dark) * (1f - 0.85f * night)
        val u = min(w, h * 0.62f) / 100f
        val fx = 400f / w

        val s = sin(t * 0.8f) * (0.7f + 0.3f * sin(t * 0.31f))
        val m = max(0f, s)
        gw = m * m
        angle = (angle + min(dt * (0.25f + wind * 3f * (0.5f + gw)), 0.3f)) % (2f * PI.toFloat())

        fun hb(x: Float) = h * 0.62f + sin(x * 0.005f * fx + 3f) * h * 0.025f
        fun hf(x: Float) = h * 0.74f + sin(x * 0.007f * fx + 1f) * h * 0.02f

        // céu
        val wv = warm * (1f - dark) * (1f - cloud * 0.5f)
        val top = mixC(
            mixC(mixC(rgb(86, 172, 238), rgb(10, 16, 40), night), mixC(rgb(34, 42, 58), rgb(14, 18, 32), night), dark),
            rgb(96, 92, 150), wv * 0.5f
        )
        val bot = mixC(
            mixC(mixC(rgb(204, 238, 250), rgb(34, 48, 88), night), mixC(rgb(100, 112, 128), rgb(26, 32, 48), night), dark),
            rgb(250, 150, 90), wv * 0.85f
        )
        paint.shader = LinearGradient(0f, 0f, 0f, h * 0.7f, top, bot, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        // estrelas, sol e lua
        val na = night * clamp01(1f - cloud * 1.2f)
        if (na > 0.02f) {
            paint.color = Color.WHITE
            for (i in starX.indices) {
                paint.alpha = (255f * clamp01(na * (0.55f + 0.45f * sin(t * 2f + starP[i])))).toInt()
                c.drawCircle(starX[i] * w, starY[i] * h, u * 0.35f + 1f, paint)
            }
            paint.alpha = 255
        }
        val stt = (hour - 5.5f) / 13.5f
        sunT = stt
        val sa = clamp01(1f - cloud * 1.15f) * (if (stt > -0.06f && stt < 1.06f) 1f else 0f)
        if (sa > 0.02f) {
            val sx = w * (0.12f + 0.76f * stt)
            val sy = h * 0.6f - sin(PI.toFloat() * clamp01(stt)) * h * 0.46f
            val r = 7f * u
            val col = mixC(rgb(255, 238, 160), rgb(255, 140, 60), warm)
            paint.shader = RadialGradient(sx, sy, r * 4f, withAlpha(col, 0.55f * sa), withAlpha(col, 0f), Shader.TileMode.CLAMP)
            c.drawCircle(sx, sy, r * 4f, paint)
            paint.shader = null
            paint.color = withAlpha(col, sa)
            c.drawCircle(sx, sy, r, paint)
        }
        val nt = ((hour - 19f + 24f) % 24f) / 10.5f
        if (na > 0.02f && nt <= 1.04f) {
            val mx = w * (0.12f + 0.76f * nt)
            val my = h * 0.58f - sin(PI.toFloat() * clamp01(nt)) * h * 0.44f
            paint.color = withAlpha(rgb(244, 242, 226), na)
            c.drawCircle(mx, my, 5f * u, paint)
        }

        // nuvens
        paint.isFilterBitmap = true
        for (i in 0 until 8) {
            val a = clamp01(cloud * 9f - i * 0.9f) * 0.95f
            if (a <= 0f) continue
            val cl = clouds[i]
            cl[0] += (0.004f + wind * 0.03f) * cl[3] * dt
            if (cl[0] > 1.3f) cl[0] = -0.3f
            val wd = 40f * u * cl[2]
            val ht = wd * 0.4667f
            val px = cl[0] * w
            val py = cl[1] * h
            val dst = RectF(px - wd / 2, py - ht / 2, px + wd / 2, py + ht / 2)
            val sp = sprites[i % 3]
            paint.alpha = (255f * clamp01(a * (1f - dk))).toInt()
            c.drawBitmap(sp[0], null, dst, paint)
            if (dk > 0.02f) {
                paint.alpha = (255f * clamp01(a * dk)).toInt()
                c.drawBitmap(sp[1], null, dst, paint)
            }
            val wa = warm * (1f - dk) * a * 0.8f
            if (wa > 0.02f) {
                paint.alpha = (255f * clamp01(wa)).toInt()
                c.drawBitmap(sp[2], null, dst, paint)
            }
        }
        paint.alpha = 255
        extras.birds(c, w, h, u, t, cloud, rain, night, dt)

        // montanhas, colinas, casa, moinho
        fun hill(base: Float, amp: Float, freq: Float, ph: Float, color: Int) {
            val p = Path()
            p.moveTo(0f, h)
            var x = 0f
            while (x <= w + 8f) {
                p.lineTo(x, h * base + sin(x * freq * fx + ph) * h * amp)
                x += 8f
            }
            p.lineTo(w, h)
            p.close()
            paint.color = color
            c.drawPath(p, paint)
        }
        hill(0.575f, 0.03f, 0.004f, 0.6f, mixC(rgb(128, 156, 190), bot, 0.4f + 0.25f * dk))
        hill(0.62f, 0.025f, 0.005f, 3f, mixC(rgb(120, 186, 96), rgb(48, 78, 64), dk))

        extras.shade(c, w * 0.2f, hb(w * 0.2f) + u, 22f * u, 16f * u, u, stt, cloud, night)
        drawHouse(c, w * 0.2f, hb(w * 0.2f) + u, u, dk)
        drawSmoke(c, w * 0.2f + 7f * u, hb(w * 0.2f) + u - 20f * u, u, dk, dt)
        extras.shade(c, w * 0.74f, hb(w * 0.74f) + u, 12f * u, 30f * u, u, stt, cloud, night)
        drawMill(c, w * 0.74f, hb(w * 0.74f) + u, u, dk)

        hill(0.74f, 0.02f, 0.007f, 1f, mixC(rgb(92, 160, 72), rgb(34, 62, 48), dk))
        extras.fence(c, w, u, dk) { x -> hf(x) }
        for (tr in arrayOf(floatArrayOf(0.08f, 1.0f), floatArrayOf(0.40f, 0.8f), floatArrayOf(0.58f, 1.1f), floatArrayOf(0.93f, 0.9f))) {
            val tx = w * tr[0]
            val ty = hf(tx) + 2f * u
            extras.shade(c, tx, ty, 3f * u * tr[1], 18f * u * tr[1], u, stt, cloud, night)
            drawTree(c, tx, ty, u, tr[1], dk)
        }
        extras.grass(c, w, u, dk, wind, gw, t) { x -> hf(x) }
        extras.herd(c, w, h, u, dk, night, rain, t, dt) { x -> hf(x) }
        extras.fireflies(c, w, h, u, night, cloud, rain, t) { x -> hf(x) }
        extras.meteor(c, w, h, night, cloud, dt)

        // chuva
        val n = (280 * rain).toInt()
        if (n > 0) {
            val lines = FloatArray(n * 4)
            val dx = 2f + wind * 10f
            for (i in 0 until n) {
                dropY[i] += dropV[i] * dt * 1.3f
                dropX[i] += (0.02f + wind * 0.12f) * dt
                if (dropY[i] > 1f) { dropY[i] = -0.05f; dropX[i] = Random.nextFloat() * 1.1f - 0.1f }
                if (dropX[i] > 1.1f) dropX[i] -= 1.2f
                lines[i * 4] = dropX[i] * w
                lines[i * 4 + 1] = dropY[i] * h
                lines[i * 4 + 2] = dropX[i] * w + dx * (w / 400f)
                lines[i * 4 + 3] = dropY[i] * h + 16f * (w / 400f)
            }
            paint.color = Color.argb(128, 215, 230, 255)
            paint.strokeWidth = 1.3f * (w / 400f)
            c.drawLines(lines, paint)
        }

        // raios
        if (storm > 0.5f) {
            nextFlash -= dt
            if (nextFlash <= 0f) {
                var bx: Float
                do { bx = w * (0.12f + Random.nextFloat() * 0.76f) } while (abs(bx - lastBolt) < w * 0.25f)
                lastBolt = bx
                val pts = ArrayList<PointF>()
                var x = bx
                var y = h * (0.08f + Random.nextFloat() * 0.1f)
                pts.add(PointF(x, y))
                while (y < hb(x)) {
                    y += 22f + Random.nextFloat() * 26f
                    x += Random.nextFloat() * 46f - 23f
                    pts.add(PointF(x, y))
                }
                bolt = pts
                flash = 1f
                nextFlash = if (Random.nextFloat() < 0.35f) 0.3f + Random.nextFloat() * 0.5f else 2.5f + Random.nextFloat() * 5f
            }
        }
        flash = max(0f, flash - dt * 2.5f)
        if (flash > 0f) {
            paint.color = Color.argb((255f * flash * 0.45f).toInt(), 235, 240, 255)
            c.drawRect(0f, 0f, w, h, paint)
            val b = bolt
            if (b != null && flash > 0.35f) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2.5f * (w / 400f)
                paint.color = Color.WHITE
                val p = Path()
                p.moveTo(b[0].x, b[0].y)
                for (i in 1 until b.size) p.lineTo(b[i].x, b[i].y)
                c.drawPath(p, paint)
                paint.style = Paint.Style.FILL
            }
        }
    }

    private fun drawHouse(c: Canvas, x: Float, y: Float, u: Float, dk: Float) {
        val wd = 22f * u
        val ht = 12f * u
        paint.color = mixC(rgb(236, 222, 196), rgb(88, 92, 104), dk)
        c.drawRect(x - wd / 2, y - ht, x + wd / 2, y, paint)
        paint.color = Color.argb(41, 40, 40, 60)
        c.drawRect(if (sunT < 0.5f) x else x - wd / 2, y - ht, if (sunT < 0.5f) x + wd / 2 else x, y, paint)
        val roof = Path()
        roof.moveTo(x - wd / 2 - 2f * u, y - ht)
        roof.lineTo(x, y - ht - 9f * u)
        roof.lineTo(x + wd / 2 + 2f * u, y - ht)
        roof.close()
        paint.color = mixC(rgb(178, 84, 62), rgb(70, 50, 52), dk)
        c.drawPath(roof, paint)
        c.drawRect(x + wd / 4, y - ht - 8f * u, x + wd / 4 + 3f * u, y - ht - 2f * u, paint)
        val lit = clamp01((dk - 0.35f) * 3f)
        val wx = x - wd / 4 - 2f * u
        val wy = y - ht * 0.7f
        val moldura = mixC(rgb(120, 84, 60), rgb(50, 40, 40), dk)
        paint.color = moldura
        c.drawRect(wx - 0.6f * u, wy - 0.6f * u, wx + 4.6f * u, wy + 4.6f * u, paint)
        paint.color = if (lit > 0f) withAlpha(rgb(255, 214, 120), 0.45f + 0.55f * lit) else mixC(rgb(62, 80, 98), rgb(28, 34, 44), dk)
        c.drawRect(wx, wy, wx + 4f * u, wy + 4f * u, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = max(1f, 0.4f * u)
        paint.color = moldura
        c.drawLine(wx + 2f * u, wy, wx + 2f * u, wy + 4f * u, paint)
        c.drawLine(wx, wy + 2f * u, wx + 4f * u, wy + 2f * u, paint)
        paint.style = Paint.Style.FILL
        paint.color = mixC(rgb(120, 80, 56), rgb(50, 40, 40), dk)
        c.drawRect(x + u, y - 7f * u, x + 5f * u, y, paint)
    }

    private fun drawSmoke(c: Canvas, sx: Float, sy: Float, u: Float, dk: Float, dt: Float) {
        smokeT -= dt
        if (smokeT <= 0f) { smokeT = 0.3f; smoke.add(floatArrayOf(sx, sy, 0f)) }
        val it = smoke.iterator()
        val base = mixC(rgb(236, 236, 238), rgb(120, 126, 140), dk)
        while (it.hasNext()) {
            val p = it.next()
            p[2] += dt
            p[1] -= dt * 4f * u
            p[0] += (1f + wind * 8f * (0.4f + gw)) * u * dt * 0.8f
            if (p[2] > 4.5f) { it.remove(); continue }
            paint.color = withAlpha(base, 0.32f * clamp01(p[2] * 3f) * (1f - p[2] / 4.5f))
            c.drawCircle(p[0], p[1], (0.8f + p[2] * 0.4f) * u, paint)
        }
    }

    private fun drawMill(c: Canvas, x: Float, y: Float, u: Float, dk: Float) {
        c.save()
        c.translate(x, y)
        paint.color = mixC(rgb(240, 230, 210), rgb(92, 98, 112), dk)
        val tower = Path()
        tower.moveTo(-7f * u, 0f); tower.lineTo(7f * u, 0f); tower.lineTo(4.5f * u, -30f * u); tower.lineTo(-4.5f * u, -30f * u); tower.close()
        c.drawPath(tower, paint)
        val s2 = if (sunT < 0.5f) 1f else -1f
        val sh = Path()
        sh.moveTo(0f, 0f); sh.lineTo(s2 * 7f * u, 0f); sh.lineTo(s2 * 4.5f * u, -30f * u); sh.lineTo(0f, -30f * u); sh.close()
        paint.color = Color.argb((255f * 0.2f * (1f - dk * 0.5f)).toInt(), 40, 40, 60)
        c.drawPath(sh, paint)
        paint.color = mixC(rgb(156, 90, 62), rgb(66, 50, 52), dk)
        val roof = Path()
        roof.moveTo(-6f * u, -30f * u); roof.lineTo(6f * u, -30f * u); roof.lineTo(0f, -38f * u); roof.close()
        c.drawPath(roof, paint)
        c.drawRect(-1.8f * u, -7f * u, 1.8f * u, 0f, paint)
        c.translate(0f, -31f * u)
        c.rotate(angle * 180f / PI.toFloat())
        for (k in 0 until 4) {
            c.save()
            c.rotate(k * 90f)
            paint.style = Paint.Style.FILL
            paint.color = mixC(rgb(250, 246, 236), rgb(120, 126, 140), dk)
            c.drawRect(1.5f * u, -2f * u, 23.5f * u, 2f * u, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(1f, 0.5f * u)
            paint.color = mixC(rgb(150, 100, 70), rgb(60, 50, 50), dk)
            c.drawRect(1.5f * u, -2f * u, 23.5f * u, 2f * u, paint)
            c.drawLine(8f * u, -2f * u, 8f * u, 2f * u, paint)
            c.drawLine(15f * u, -2f * u, 15f * u, 2f * u, paint)
            paint.style = Paint.Style.FILL
            c.restore()
        }
        paint.color = mixC(rgb(120, 76, 56), rgb(50, 42, 44), dk)
        c.drawCircle(0f, 0f, 2.4f * u, paint)
        c.restore()
    }

    private fun drawTree(c: Canvas, x: Float, y: Float, u: Float, sc: Float, dk: Float) {
        val sw = wind * (0.25f + gw * 0.9f) * 11f * u * sc + sin(t * 7f + x) * wind * u * 0.5f * sc
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.4f * u * sc
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = mixC(rgb(112, 78, 52), rgb(50, 40, 38), dk)
        val trunk = Path()
        trunk.moveTo(x, y)
        trunk.quadTo(x, y - 5f * u * sc, x + sw * 0.67f, y - 10f * u * sc)
        c.drawPath(trunk, paint)
        paint.style = Paint.Style.FILL
        val blobs = arrayOf(floatArrayOf(0f, -15f, 7f), floatArrayOf(-4.5f, -11.5f, 5.5f), floatArrayOf(4.5f, -11.5f, 5.5f))
        for (b in blobs) {
            val cx = x + b[0] * u * sc + sw * (-b[1] / 15f)
            val cy = y + b[1] * u * sc
            val r = b[2] * u * sc
            paint.color = mixC(rgb(62, 144, 74), rgb(28, 62, 46), dk)
            c.drawCircle(cx, cy, r, paint)
            paint.color = mixC(rgb(96, 172, 84), rgb(40, 78, 56), dk)
            c.drawCircle(cx - 0.3f * r, cy - 0.25f * r, 0.62f * r, paint)
        }
    }
}

internal fun sq(v: Float) = v * v
internal fun clamp01(v: Float) = max(0f, min(1f, v))
internal fun smooth(a: Float, b: Float, x: Float): Float {
    val q = clamp01((x - a) / (b - a))
    return q * q * (3f - 2f * q)
}
internal fun rgb(r: Int, g: Int, b: Int) = Color.rgb(r, g, b)
internal fun withAlpha(col: Int, a: Float) = Color.argb((255f * clamp01(a)).toInt(), Color.red(col), Color.green(col), Color.blue(col))
internal fun mixC(a: Int, b: Int, t: Float): Int {
    val k = clamp01(t)
    return Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
    )
}
