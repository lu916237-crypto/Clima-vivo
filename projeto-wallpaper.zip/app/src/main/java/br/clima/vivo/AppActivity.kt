package br.clima.vivo

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import java.net.URL

/**
 * App completo: abre a versão web (paisagem, radar, previsão, trovão, "Choveu aí?") dentro de um WebView.
 * A rede (previsão e radar), a localização e o papel de parede passam por uma ponte nativa.
 */
class AppActivity : Activity() {

    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#1b2330"))
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        getSharedPreferences("clima", Context.MODE_PRIVATE).edit().putString("estado", "auto").putFloat("hora", -1f).apply()
        web.addJavascriptInterface(Ponte(), "NativeBridge")
        setContentView(web)
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            guardarLocalizacao()
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 1)
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        guardarLocalizacao()
        web.evaluateJavascript("if(window.refresh)refresh();if(window.rrLoad)rrLoad(true);", null)
    }

    override fun onPause() {
        web.onPause()
        web.pauseTimers()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.resumeTimers()
        web.evaluateJavascript("if(window.__resume)__resume()", null)
    }

    override fun onBackPressed() {
        web.evaluateJavascript("(window.__back?window.__back():false)") { r ->
            if (r != "true") finish()
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    inner class Ponte {
        @JavascriptInterface
        fun getLoc(): String {
            val p = getSharedPreferences("clima", Context.MODE_PRIVATE)
            return p.getFloat("lat", -29.76f).toString() + "," + p.getFloat("lon", -50.02f).toString()
        }

        @JavascriptInterface
        fun fetch(id: Int, url: String) {
            val host = try { URL(url).host } catch (e: Exception) { "" }
            if (!(host.endsWith("open-meteo.com") || host.endsWith("rainviewer.com"))) {
                responder(id, false, "dominio nao permitido")
                return
            }
            Thread {
                try {
                    val b64 = Base64.encodeToString(DadosClima.baixarBytes(url), Base64.NO_WRAP)
                    responder(id, true, b64)
                } catch (e: Exception) {
                    responder(id, false, (e.message ?: "falha").replace("'", " ").replace("\n", " "))
                }
            }.start()
        }

        @JavascriptInterface
        fun trovao(vol: Double) {
            runOnUiThread { tocarTrovao(vol.toFloat()) }
        }

        @JavascriptInterface
        fun abrirPapelDeParede() {
            runOnUiThread { abrirSeletor() }
        }

        @JavascriptInterface
        fun abrirTestes() {
            runOnUiThread { startActivity(Intent(this@AppActivity, MainActivity::class.java)) }
        }
    }

    /** Toca o trovão pelo volume de mídia; outros apps de áudio abaixam o volume enquanto ele toca. */
    private fun tocarTrovao(vol: Float) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .build()
            am.requestAudioFocus(req)
            val mp = MediaPlayer()
            mp.setAudioAttributes(attrs)
            val afd = resources.openRawResourceFd(R.raw.trovao)
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            val v = Math.max(0.2f, Math.min(1f, vol))
            mp.setVolume(v, v)
            mp.setOnCompletionListener { p ->
                p.release()
                am.abandonAudioFocusRequest(req)
            }
            mp.prepare()
            mp.start()
        } catch (e: Exception) {
        }
    }

    private fun responder(id: Int, ok: Boolean, texto: String) {
        runOnUiThread { web.evaluateJavascript("__nb($id,$ok,'$texto')", null) }
    }

    private fun abrirSeletor() {
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            i.putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, SkyWallpaperService::class.java)
            )
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                Toast.makeText(this, "Abra Papel de parede e estilo nas configurações", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun guardarLocalizacao() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var melhor: Location? = null
        for (nome in lm.getProviders(true)) {
            val l = try { lm.getLastKnownLocation(nome) } catch (e: SecurityException) { null }
            val atual = melhor
            if (l != null && (atual == null || l.time > atual.time)) melhor = l
        }
        val achou = melhor
        if (achou != null) {
            getSharedPreferences("clima", Context.MODE_PRIVATE).edit()
                .putFloat("lat", achou.latitude.toFloat())
                .putFloat("lon", achou.longitude.toFloat())
                .apply()
        }
    }
}
