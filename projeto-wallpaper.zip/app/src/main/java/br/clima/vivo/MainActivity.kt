package br.clima.vivo

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Tela simples: definir como papel de parede e botões de teste (tempo e hora). */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("clima", Context.MODE_PRIVATE)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(48, 96, 48, 48)

        fun titulo(texto: String) {
            val v = TextView(this)
            v.text = texto
            v.textSize = 17f
            v.setPadding(0, 36, 0, 12)
            root.addView(v)
        }
        fun botao(texto: String, acao: View.OnClickListener) {
            val b = Button(this)
            b.text = texto
            b.isAllCaps = false
            b.setOnClickListener(acao)
            root.addView(b)
        }

        titulo("Clima vivo Fundo")
        botao("Definir como papel de parede", View.OnClickListener {
            try {
                val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                i.putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this, SkyWallpaperService::class.java)
                )
                startActivity(i)
            } catch (e: Exception) {
                try {
                    startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                } catch (e2: Exception) {
                    Toast.makeText(this, "Abra Papel de parede e estilo nas configurações", Toast.LENGTH_LONG).show()
                }
            }
        })

        titulo("Tempo (para teste)")
        val estados = listOf("sol" to "Sol", "nublado" to "Nublado", "ventania" to "Ventania", "chuva" to "Chuva", "tempestade" to "Tempestade")
        for ((chave, nome) in estados) {
            botao(nome, View.OnClickListener {
                prefs.edit().putString("estado", chave).apply()
                Toast.makeText(this, "Tempo: $nome", Toast.LENGTH_SHORT).show()
            })
        }

        titulo("Hora (para teste)")
        val horas = listOf(-1f to "Hora real", 6f to "6h", 12f to "12h", 17.5f to "17h30", 19f to "19h", 22f to "22h")
        for ((valor, nome) in horas) {
            botao(nome, View.OnClickListener {
                prefs.edit().putFloat("hora", valor).apply()
                Toast.makeText(this, "Hora: $nome", Toast.LENGTH_SHORT).show()
            })
        }

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }
}
