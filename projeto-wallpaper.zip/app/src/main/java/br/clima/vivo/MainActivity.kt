package br.clima.vivo

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Tela simples: definir como papel de parede, ver os dados reais e botões de teste. */
class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("clima", Context.MODE_PRIVATE)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(48, 96, 48, 48)

        fun titulo(texto: String) {
            val v = TextView(this)
            v.text = texto
            v.textSize = 17f
            v.setPadding(0, 36, 0, 12)
            root.addView(v)
        }
        fun botao(texto: String, acao: View.OnClickListener) {
            val b = Button(this)
            b.text = texto
            b.isAllCaps = false
            b.setOnClickListener(acao)
            root.addView(b)
        }

        titulo("Clima vivo Fundo")
        status = TextView(this)
        status.textSize = 15f
        root.addView(status)

        botao("Definir como papel de parede", View.OnClickListener {
            try {
                val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                i.putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this, SkyWallpaperService::class.java)
                )
                startActivity(i)
            } catch (e: Exception) {
                try {
                    startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                } catch (e2: Exception) {
                    Toast.makeText(this, "Abra Papel de parede e estilo nas configurações", Toast.LENGTH_LONG).show()
                }
            }
        })

        titulo("Tempo real")
        botao("Usar previsão e radar reais (automático)", View.OnClickListener {
            prefs.edit().putString("estado", "auto").apply()
            Toast.makeText(this, "Modo automático", Toast.LENGTH_SHORT).show()
            atualizar()
        })
        botao("Atualizar agora", View.OnClickListener { atualizar() })
        botao("Usar minha localização", View.OnClickListener { pedirLocalizacao() })

        titulo("Testes (tempo fixo)")
        val estados = listOf("sol" to "Sol", "nublado" to "Nublado", "ventania" to "Ventania", "chuva" to "Chuva", "tempestade" to "Tempestade")
        for ((chave, nome) in estados) {
            botao(nome, View.OnClickListener {
                prefs.edit().putString("estado", chave).apply()
                Toast.makeText(this, "Tempo fixo: $nome", Toast.LENGTH_SHORT).show()
            })
        }

        titulo("Hora (para teste)")
        val horas = listOf(-1f to "Hora real", 6f to "6h", 12f to "12h", 17.5f to "17h30", 19f to "19h", 22f to "22h")
        for ((valor, nome) in horas) {
            botao(nome, View.OnClickListener {
                prefs.edit().putFloat("hora", valor).apply()
                Toast.makeText(this, "Hora: $nome", Toast.LENGTH_SHORT).show()
            })
        }

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        guardarLocalizacao()
        if (DadosClima.precisaAtualizar(this)) atualizar()
    }

    override fun onResume() {
        super.onResume()
        mostrarStatus()
    }

    private fun mostrarStatus() {
        val p = getSharedPreferences("clima", Context.MODE_PRIVATE)
        val modo = p.getString("estado", "auto") ?: "auto"
        val lat = p.getFloat("lat", -29.76f)
        val lon = p.getFloat("lon", -50.02f)
        val dados = p.getString("l_txt", "Ainda sem dados. Toque em Atualizar agora.") ?: ""
        status.text = "Modo: " + modo + "\nLocal: " + String.format("%.2f, %.2f", lat, lon) + "\n\n" + dados
    }

    private fun atualizar() {
        status.text = "Atualizando..."
        DadosClima.atualizar(this) { runOnUiThread { mostrarStatus() } }
    }

    private fun pedirLocalizacao() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            guardarLocalizacao()
            atualizar()
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 1)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        guardarLocalizacao()
        atualizar()
    }

    private fun guardarLocalizacao() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var melhor: Location? = null
        for (nome in lm.getProviders(true)) {
            val l = try { lm.getLastKnownLocation(nome) } catch (e: SecurityException) { null }
            val atual = melhor
            if (l != null && (atual == null || l.time > atual.time)) melhor = l
        }
        val achou = melhor
        if (achou != null) {
            getSharedPreferences("clima", Context.MODE_PRIVATE).edit()
                .putFloat("lat", achou.latitude.toFloat())
                .putFloat("lon", achou.longitude.toFloat())
                .apply()
        }
    }
}
