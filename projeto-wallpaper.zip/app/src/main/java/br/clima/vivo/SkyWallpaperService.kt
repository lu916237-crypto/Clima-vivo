package br.clima.vivo

import android.content.Context
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

/**
 * Papel de parede animado do Clima vivo. Só desenha com a tela visível (economiza bateria).
 * O estado do tempo e a hora (para teste) vêm das preferências gravadas pela tela do app.
 */
class SkyWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = SkyEngine()

    inner class SkyEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val prefs = getSharedPreferences("clima", Context.MODE_PRIVATE)
        private val scene = SceneRenderer()
        private var visible = false
        private var last = System.nanoTime()
        private val tick = Runnable { drawFrame() }
        private val refresh = object : Runnable {
            override fun run() {
                if (visible) {
                    DadosClima.atualizar(this@SkyWallpaperService)
                    handler.postDelayed(this, 10 * 60_000L)
                }
            }
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            if (isVisible) {
                last = System.nanoTime()
                drawFrame()
                if (DadosClima.precisaAtualizar(this@SkyWallpaperService)) DadosClima.atualizar(this@SkyWallpaperService)
                handler.removeCallbacks(refresh)
                handler.postDelayed(refresh, 10 * 60_000L)
            } else {
                handler.removeCallbacks(tick)
                handler.removeCallbacks(refresh)
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(tick)
            handler.removeCallbacks(refresh)
            super.onSurfaceDestroyed(holder)
        }

        private fun drawFrame() {
            val now = System.nanoTime()
            val dt = (now - last) / 1_000_000_000f
            last = now
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    val estado = prefs.getString("estado", "auto") ?: "auto"
                    val hora = prefs.getFloat("hora", -1f)
                    val auto = if (estado == "auto") floatArrayOf(
                        prefs.getFloat("l_cloud", 0.12f), prefs.getFloat("l_wind", 0.2f), prefs.getFloat("l_rain", 0f),
                        prefs.getFloat("l_dark", 0.05f), prefs.getFloat("l_storm", 0f)
                    ) else null
                    scene.draw(canvas, canvas.width.toFloat(), canvas.height.toFloat(), estado, hora, dt, auto)
                }
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
            handler.removeCallbacks(tick)
            if (visible) handler.postDelayed(tick, 66L)   // ~15 quadros por segundo
        }
    }
}
