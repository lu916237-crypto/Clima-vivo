package br.clima.vivo

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * TESTE do papel de parede animado do Clima vivo.
 * Desenha um céu que muda com a hora real do celular (amanhecer, dia, entardecer, noite),
 * sol, lua, estrelas e colinas. Só desenha enquanto a tela está visível (economiza bateria).
 */
class SkyWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = SkyEngine()

    inner class SkyEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var visible = false
        private val starX = FloatArray(70) { Random.nextFloat() }
        private val starY = FloatArray(70) { Random.nextFloat() * 0.5f }
        private val starP = FloatArray(70) { Random.nextFloat() * 6f }
        private val tick = Runnable { drawFrame() }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            if (isVisible) drawFrame() else handler.removeCallbacks(tick)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(tick)
            super.onSurfaceDestroyed(holder)
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) paintScene(canvas)
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
            handler.removeCallbacks(tick)
            if (visible) handler.postDelayed(tick, 100L)   // ~10 quadros por segundo
        }

        private fun hourNow(): Float {
            val c = Calendar.getInstance()
            return c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE) / 60f + c.get(Calendar.SECOND) / 3600f
        }

        private fun paintScene(c: Canvas) {
            val w = c.width.toFloat()
            val h = c.height.toFloat()
            val hour = hourNow()
            val night = if (hour < 12f) 1f - smooth(4.75f, 6.25f, hour) else smooth(18.25f, 19.75f, hour)
            val warm = clamp01(
                exp(-sq((hour - 19f) / 0.8f)) + exp(-sq((hour - 5.5f) / 0.8f))
            )
            val dk = 0.85f * night

            // céu
            val top = mixColor(mixColor(Color.rgb(86, 172, 238), Color.rgb(10, 16, 40), night), Color.rgb(96, 92, 150), warm * 0.5f)
            val bot = mixColor(mixColor(Color.rgb(204, 238, 250), Color.rgb(34, 48, 88), night), Color.rgb(250, 150, 90), warm * 0.85f)
            paint.shader = LinearGradient(0f, 0f, 0f, h * 0.7f, top, bot, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, paint)
            paint.shader = null

            // estrelas
            if (night > 0.02f) {
                val t = System.currentTimeMillis() / 1000f
                paint.color = Color.WHITE
                for (i in starX.indices) {
                    val a = night * (0.55f + 0.45f * sin(t * 2f + starP[i]))
                    paint.alpha = (255f * clamp01(a)).toInt()
                    c.drawCircle(starX[i] * w, starY[i] * h, w * 0.0025f + 1f, paint)
                }
                paint.alpha = 255
            }

            // sol
            val stt = (hour - 5.5f) / 13.5f
            if (stt > -0.06f && stt < 1.06f) {
                val sx = w * (0.12f + 0.76f * stt)
                val sy = h * 0.6f - sin(PI.toFloat() * clamp01(stt)) * h * 0.46f
                val r = w * 0.07f
                val col = mixColor(Color.rgb(255, 238, 160), Color.rgb(255, 140, 60), warm)
                paint.shader = RadialGradient(
                    sx, sy, r * 4f,
                    Color.argb(140, Color.red(col), Color.green(col), Color.blue(col)),
                    Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                    Shader.TileMode.CLAMP
                )
                c.drawCircle(sx, sy, r * 4f, paint)
                paint.shader = null
                paint.color = col
                c.drawCircle(sx, sy, r, paint)
            }

            // lua
            val nt = ((hour - 19f + 24f) % 24f) / 10.5f
            if (night > 0.02f && nt <= 1.04f) {
                val mx = w * (0.12f + 0.76f * nt)
                val my = h * 0.58f - sin(PI.toFloat() * clamp01(nt)) * h * 0.44f
                paint.color = Color.rgb(244, 242, 226)
                paint.alpha = (255f * clamp01(night)).toInt()
                c.drawCircle(mx, my, w * 0.05f, paint)
                paint.alpha = 255
            }

            // montanhas ao longe e colinas
            hill(c, w, h, 0.575f, 0.03f, 0.004f, 0.6f, mixColor(Color.rgb(128, 156, 190), bot, 0.4f + 0.25f * dk))
            hill(c, w, h, 0.62f, 0.025f, 0.005f, 3f, mixColor(Color.rgb(120, 186, 96), Color.rgb(48, 78, 64), dk))
            hill(c, w, h, 0.74f, 0.02f, 0.007f, 1f, mixColor(Color.rgb(92, 160, 72), Color.rgb(34, 62, 48), dk))
        }

        private fun hill(c: Canvas, w: Float, h: Float, base: Float, amp: Float, freq: Float, phase: Float, color: Int) {
            val f = freq * 400f / w
            val p = Path()
            p.moveTo(0f, h)
            var x = 0f
            while (x <= w + 8f) {
                p.lineTo(x, h * base + sin(x * f + phase) * h * amp)
                x += 8f
            }
            p.lineTo(w, h)
            p.close()
            paint.color = color
            c.drawPath(p, paint)
        }
    }
}

private fun sq(v: Float) = v * v
private fun clamp01(v: Float) = max(0f, min(1f, v))
private fun smooth(a: Float, b: Float, x: Float): Float {
    val t = clamp01((x - a) / (b - a))
    return t * t * (3f - 2f * t)
}
private fun mixColor(a: Int, b: Int, t: Float): Int {
    val k = clamp01(t)
    return Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
    )
}
