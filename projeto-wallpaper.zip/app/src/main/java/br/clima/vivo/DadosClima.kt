package br.clima.vivo

import android.content.Context
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Busca a previsão real (Open-Meteo, 3 modelos) e o radar real (RainViewer), combina e grava
 * os alvos da paisagem nas preferências. A paisagem lê esses valores no modo "automático".
 */
object DadosClima {
    private val modelos = listOf("ecmwf_ifs025", "gfs_seamless", "icon_seamless")
    @Volatile private var rodando = false

    class Previsao(val p3: Float, val conf: Float, val tempC: Float?, val vento: Float?, val nuvens: Float?, val mm: Float, val n: Int)
    class Radar(val coberto: Boolean?, val agora: Boolean, val km: Float, val dbz: Float)

    fun precisaAtualizar(ctx: Context): Boolean {
        val p = ctx.getSharedPreferences("clima", Context.MODE_PRIVATE)
        return System.currentTimeMillis() - p.getLong("l_at", 0L) > 9 * 60_000L
    }

    fun atualizar(ctx: Context, aoTerminar: (() -> Unit)? = null) {
        if (rodando) return
        rodando = true
        val app = ctx.applicationContext
        Thread {
            try {
                executar(app)
            } catch (e: Exception) {
                app.getSharedPreferences("clima", Context.MODE_PRIVATE).edit()
                    .putString("l_txt", "Erro ao atualizar: " + e.javaClass.simpleName).apply()
            } finally {
                rodando = false
                aoTerminar?.invoke()
            }
        }.start()
    }

    private fun clamp01(v: Float) = max(0f, min(1f, v))

    private fun executar(ctx: Context) {
        val p = ctx.getSharedPreferences("clima", Context.MODE_PRIVATE)
        val lat = p.getFloat("lat", -29.76f).toDouble()
        val lon = p.getFloat("lon", -50.02f).toDouble()
        var erroPrev = ""
        var erroRad = ""
        val pv: Previsao? = try { previsao(lat, lon) } catch (e: Exception) { erroPrev = e.message ?: e.javaClass.simpleName; null }
        val rd: Radar? = try { radar(lat, lon) } catch (e: Exception) { erroRad = e.message ?: e.javaClass.simpleName; null }

        var cloud = 0.12f
        var wind = 0.2f
        var rain = 0f
        var dark = 0.05f
        var storm = 0f
        if (pv != null) {
            val raining = pv.p3 >= 0.5f && pv.mm >= 0.1f
            rain = if (raining) clamp01(0.25f + pv.mm / 6f) else 0f
            val cover = (pv.nuvens ?: (pv.p3 * 100f)) / 100f
            cloud = clamp01(max(cover, max(pv.p3 * 0.9f + 0.05f, if (raining) 0.9f else 0f)))
            wind = clamp01((pv.vento ?: 10f) / 55f)
            storm = if (rain > 0.7f && pv.mm >= 4f) 1f else 0f
            dark = clamp01(cloud * 0.45f + rain * 0.5f)
        }
        if (rd != null && rd.coberto != false) {
            if (rd.agora) {
                val mm = (10.0.pow(rd.dbz / 10.0) / 200.0).pow(1.0 / 1.6).toFloat()
                rain = max(rain, clamp01(0.3f + mm / 8f))
                cloud = max(cloud, 0.9f)
                dark = max(dark, 0.6f)
                if (rd.dbz >= 45f) storm = 1f
            } else {
                if (rd.coberto == true) { rain = 0f; storm = 0f }      // o radar cobre aqui e não vê chuva agora
                if (rd.km < 60f) {
                    val q = clamp01(1f - rd.km / 60f)
                    cloud = max(cloud, 0.12f + 0.83f * q)
                    dark = max(dark, q * 0.65f)
                }
            }
        }

        val hora = SimpleDateFormat("HH:mm", Locale.US).format(Date())
        val linhaPrev = if (pv != null) {
            val conf = if (pv.conf > 0.75f) "alta" else if (pv.conf > 0.5f) "média" else "baixa"
            (if (pv.tempC != null) Math.round(pv.tempC).toString() + "° · " else "") +
                "chuva " + Math.round(pv.p3 * 100f) + "% nas próximas 3 h (confiança " + conf + ", " + pv.n + " modelos)"
        } else "previsão indisponível ($erroPrev)"
        val linhaRad = if (rd != null) {
            (if (rd.agora) "chuva sobre você" else if (rd.km < 100f) "chuva a " + Math.round(rd.km) + " km" else "sem chuva em 100 km") +
                (when (rd.coberto) { true -> " (cobertura ok)"; false -> " (SEM radar cobrindo seu local)"; null -> " (cobertura desconhecida)" })
        } else "radar indisponível ($erroRad)"

        p.edit()
            .putFloat("l_cloud", cloud).putFloat("l_wind", wind).putFloat("l_rain", rain)
            .putFloat("l_dark", dark).putFloat("l_storm", storm)
            .putLong("l_at", System.currentTimeMillis())
            .putString("l_txt", "Previsão: $linhaPrev\nRadar: $linhaRad\nAtualizado às $hora")
            .apply()
    }

    // ---------- previsão (Open-Meteo) ----------
    private fun num(a: JSONArray?, i: Int): Double? =
        if (a == null || i < 0 || i >= a.length() || a.isNull(i)) null else a.optDouble(i)

    private fun mediana(v: List<Double>): Double? {
        if (v.isEmpty()) return null
        val s = v.sorted()
        return s[s.size / 2]
    }

    private fun previsao(lat: Double, lon: Double): Previsao {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=" + String.format(Locale.US, "%.3f", lat) +
            "&longitude=" + String.format(Locale.US, "%.3f", lon) +
            "&hourly=temperature_2m,precipitation,precipitation_probability,cloud_cover,wind_speed_10m" +
            "&models=" + modelos.joinToString(",") + "&timezone=auto&forecast_days=2"
        val j = JSONObject(baixarTexto(url))
        val h = j.getJSONObject("hourly")
        val tempos = h.getJSONArray("time")
        val off = j.optInt("utc_offset_seconds", 0)
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:00", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val agora = fmt.format(Date(System.currentTimeMillis() + off * 1000L))
        var i0 = 0
        for (i in 0 until tempos.length()) if (tempos.getString(i) == agora) { i0 = i; break }

        val ps = ArrayList<Double>()
        val mms = ArrayList<Double>()
        val temps = ArrayList<Double>()
        val ventos = ArrayList<Double>()
        val nuvens = ArrayList<Double>()
        for (m in modelos) {
            val pr = h.optJSONArray("precipitation_$m") ?: continue
            if (num(pr, i0) == null) continue
            val pp = h.optJSONArray("precipitation_probability_$m")
            val janela = listOf(i0, i0 + 1, i0 + 2)
            val probs = janela.map { num(pp, it) }
            val winP = if (pp != null && probs.all { it != null }) {
                probs.maxOf { it ?: 0.0 } / 100.0
            } else {
                1.0 - exp(-janela.sumOf { num(pr, it) ?: 0.0 } / 1.5)
            }
            ps.add(winP)
            mms.add(num(pr, i0) ?: 0.0)
            num(h.optJSONArray("temperature_2m_$m"), i0)?.let { temps.add(it) }
            num(h.optJSONArray("wind_speed_10m_$m"), i0)?.let { ventos.add(it) }
            num(h.optJSONArray("cloud_cover_$m"), i0)?.let { nuvens.add(it) }
        }
        if (ps.isEmpty()) throw Exception("nenhum modelo respondeu")
        val media = ps.average()
        val desvio = sqrt(ps.map { (it - media) * (it - media) }.average())
        val concordancia = (1.0 - min(1.0, max(0.0, desvio * 2.0))).toFloat()
        val conf = if (ps.size >= 3) concordancia else concordancia * 0.85f
        return Previsao(
            media.toFloat(), conf,
            mediana(temps)?.toFloat(), mediana(ventos)?.toFloat(), mediana(nuvens)?.toFloat(),
            (mediana(mms) ?: 0.0).toFloat(), ps.size
        )
    }

    // ---------- radar (RainViewer) ----------
    private val UBH = ("88ddee 6cd1eb 51c5e8 36bae5 1baee2 00a3e0 009ad5 0091ca 0088bf 007fb4 0077aa 0070a3 00699c 006295 " +
        "005b8e 005588 005180 004e78 004a70 004768 ffee00 ffe000 ffd200 ffc500 ffb700 ffaa00 ff9f00 ff9500 ff8b00 ff8100 " +
        "ff4400 f23600 e62800 d91b00 cd0d00 c10000 a80000 8f0000 760000 5d0000 ffaaff ff9fff ff95ff ff8bff ff81ff ff77ff " +
        "ff6cff ff62ff ff58ff ff4eff").split(" ")
    private val paleta = HashMap<Int, Int>()
    private val vizinha = HashMap<Int, Int>()

    init {
        for ((i, hex) in UBH.withIndex()) paleta[Integer.parseInt(hex, 16)] = 15 + i
        paleta[0xFFFFFF] = 65
        paleta[0x00FF00] = 75
    }

    private fun dbzDe(pix: Int): Float {
        val a = pix ushr 24
        if (a < 255) return if (a > 0) 8f else 0f
        val rgb = pix and 0xFFFFFF
        val exato = paleta[rgb]
        if (exato != null) return exato.toFloat()
        val cache = vizinha[rgb]
        if (cache != null) return cache.toFloat()
        var melhor = Int.MAX_VALUE
        var v = 0
        val r = (rgb shr 16) and 255
        val g = (rgb shr 8) and 255
        val b = rgb and 255
        for ((cor, dbz) in paleta) {
            val dr = ((cor shr 16) and 255) - r
            val dg = ((cor shr 8) and 255) - g
            val db = (cor and 255) - b
            val d = dr * dr + dg * dg + db * db
            if (d < melhor) { melhor = d; v = dbz }
        }
        if (melhor > 3600) v = 0
        vizinha[rgb] = v
        return v.toFloat()
    }

    private fun lonX(lon: Double) = (lon + 180.0) / 360.0 * 128.0
    private fun latY(lat: Double): Double {
        val r = lat * PI / 180.0
        return (1.0 - ln(tan(r) + 1.0 / cos(r)) / PI) / 2.0 * 128.0
    }

    private fun pixelsDe(url: String): IntArray {
        val bytes = baixarBytes(url)
        val bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: throw Exception("imagem inválida")
        val out = IntArray(bm.width * bm.height)
        bm.getPixels(out, 0, bm.width, 0, 0, bm.width, bm.height)
        return out
    }

    private fun radar(lat: Double, lon: Double): Radar {
        val j = JSONObject(baixarTexto("https://api.rainviewer.com/public/weather-maps.json"))
        val host = j.getString("host")
        val past = j.getJSONObject("radar").getJSONArray("past")
        if (past.length() == 0) throw Exception("sem quadros")
        val path = past.getJSONObject(past.length() - 1).getString("path")

        val kx = 111.32 * cos(lat * PI / 180.0)
        val ky = 110.574
        val x0 = floor(lonX(lon - 100.0 / kx)).toInt()
        val x1 = floor(lonX(lon + 100.0 / kx)).toInt()
        val y0 = floor(latY(lat + 100.0 / ky)).toInt()
        val y1 = floor(latY(lat - 100.0 / ky)).toInt()
        val tiles = HashMap<Int, FloatArray>()
        for (x in x0..x1) for (y in y0..y1) {
            val px = pixelsDe("$host$path/256/7/$x/$y/2/0_0.png")
            tiles[x * 1000 + y] = FloatArray(px.size) { dbzDe(px[it]) }
        }
        val g = FloatArray(10000)
        for (gy in 0 until 100) for (gx in 0 until 100) {
            val tx = lonX(lon + (gx - 50) * 2.0 / kx)
            val ty = latY(lat + (50 - gy) * 2.0 / ky)
            val ix = floor(tx).toInt()
            val iy = floor(ty).toInt()
            val t = tiles[ix * 1000 + iy] ?: continue
            val cx = min(255, ((tx - ix) * 256).toInt())
            val cy = min(255, ((ty - iy) * 256).toInt())
            g[gy * 100 + gx] = t[cy * 256 + cx]
        }
        // distância até a chuva mais próxima (ignora pixels isolados)
        var melhor = 999f
        var dbzPerto = 0f
        for (gy in 1 until 99) for (gx in 1 until 99) {
            if (g[gy * 100 + gx] < 20f) continue
            var viz = 0
            for (dy in -1..1) for (dx in -1..1) if ((dx != 0 || dy != 0) && g[(gy + dy) * 100 + gx + dx] >= 20f) viz++
            if (viz < 2) continue
            val d = hypot((gx - 50) * 2.0, (gy - 50) * 2.0).toFloat()
            if (d < melhor) { melhor = d; dbzPerto = g[gy * 100 + gx] }
        }
        val agora = melhor <= 3f
        // cobertura: no mapa de cobertura, transparente = há radar cobrindo
        val coberto: Boolean? = try {
            val u = "$host/v2/coverage/0/256/7/" + String.format(Locale.US, "%.4f/%.4f", lat, lon) + "/0/0_0.png"
            val c = pixelsDe(u)
            ((c[128 * 256 + 128] ushr 24) < 128)
        } catch (e: Exception) { null }
        return Radar(coberto, agora, melhor, dbzPerto)
    }

    // ---------- rede ----------
    fun baixarBytes(url: String): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", "ClimaVivo/0.3 (Android)")
        try {
            if (c.responseCode != 200) throw Exception("HTTP " + c.responseCode)
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    private fun baixarTexto(url: String) = String(baixarBytes(url), Charsets.UTF_8)
}
