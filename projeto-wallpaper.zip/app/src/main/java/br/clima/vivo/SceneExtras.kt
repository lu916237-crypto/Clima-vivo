package br.clima.vivo

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Detalhes da paisagem do app, agora também no papel de parede: sombras, cerca, capim, bichos, pássaros, vagalumes e estrela cadente. */
class SceneExtras {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // pássaros
    private val bx = FloatArray(3) { Random.nextFloat() }
    private val birdY = FloatArray(3) { 0.10f + it * 0.07f }
    private val bv = FloatArray(3) { 0.03f + it * 0.008f }
    private val bp = FloatArray(3) { it * 2f }

    // vagalumes
    private val fx = FloatArray(14) { Random.nextFloat() }
    private val fy = FloatArray(14) { 0.70f + Random.nextFloat() * 0.22f }
    private val fp = FloatArray(14) { Random.nextFloat() * 6f }
    private val fs = FloatArray(14) { 0.3f + Random.nextFloat() * 0.5f }

    // estrela cadente
    private var metOn = false
    private var metX = 0f
    private var metY = 0f
    private var metT = 0f
    private var metWait = 6f

    // bichos (0 = cavalo, 1 = boi)
    private class Herd(val kind: Int, val dir: Float, var x: Float, val v: Float, val n: Int, val ph: FloatArray)
    private var herd: Herd? = null
    private var herdWait = 1.5f
    private var lastKind = -1
    private val gap = 14f
    private val speeds = floatArrayOf(0.04f, 0.014f)
    private val scales = floatArrayOf(0.7f, 0.75f)
    private val gaits = floatArrayOf(7f, 3.5f)

    fun shade(c: Canvas, x: Float, y: Float, wd: Float, ht: Float, u: Float, stt: Float, cloud: Float, night: Float) {
        val e = sin(PI.toFloat() * clamp01(stt))
        val vis = (if (stt > -0.06f && stt < 1.06f) 1f else 0f) * (1f - cloud * 0.8f) * (1f - night)
        val a = 0.2f * vis * clamp01(e * 3f + 0.1f)
        if (a < 0.02f) return
        val len = ht * (0.25f + (1f - e) * 2.2f) * (if (stt < 0.5f) 1f else -1f)
        paint.style = Paint.Style.FILL
        paint.color = Color.argb((255f * a).toInt(), 20, 30, 20)
        val p = Path()
        p.moveTo(x - wd / 2, y); p.lineTo(x + wd / 2, y)
        p.lineTo(x + wd / 2 + len, y + u * 1.4f); p.lineTo(x - wd / 2 + len, y + u * 1.4f)
        p.close()
        c.drawPath(p, paint)
    }

    fun birds(c: Canvas, w: Float, h: Float, u: Float, t: Float, cloud: Float, rain: Float, night: Float, dt: Float) {
        for (i in 0 until 3) {
            bx[i] += bv[i] * dt
            if (bx[i] > 1.1f) { bx[i] = -0.1f; birdY[i] = 0.08f + Random.nextFloat() * 0.25f }
        }
        val a = clamp01(1.2f - cloud * 1.5f) * clamp01(1f - rain * 3f) * clamp01(1f - night * 2f)
        if (a < 0.02f) return
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = max(1f, 0.6f * u)
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = withAlpha(rgb(40, 48, 60), a * 0.85f)
        for (i in 0 until 3) {
            val f = sin(t * 9f + bp[i]) * 1.6f * u
            val px = bx[i] * w
            val py = birdY[i] * h + sin(t * 0.7f + bp[i]) * u
            val p = Path()
            p.moveTo(px - 3f * u, py - f); p.lineTo(px, py); p.lineTo(px + 3f * u, py - f)
            c.drawPath(p, paint)
        }
        paint.style = Paint.Style.FILL
    }

    fun fence(c: Canvas, w: Float, u: Float, dk: Float, hf: (Float) -> Float) {
        val x0 = w * 0.02f
        val x1 = w * 0.34f
        val n = 7
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 0.9f * u
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = mixC(rgb(150, 112, 78), rgb(52, 44, 46), dk)
        val p = Path()
        for (i in 0..n) {
            val x = x0 + (x1 - x0) * i / n
            val birdY = hf(x) + 4.5f * u
            p.moveTo(x, birdY); p.lineTo(x, birdY - 5.5f * u)
        }
        for (hh in floatArrayOf(2f, 4f)) {
            for (i in 0 until n) {
                val xa = x0 + (x1 - x0) * i / n
                val xb = x0 + (x1 - x0) * (i + 1) / n
                p.moveTo(xa, hf(xa) + 4.5f * u - hh * u); p.lineTo(xb, hf(xb) + 4.5f * u - hh * u)
            }
        }
        c.drawPath(p, paint)
        paint.style = Paint.Style.FILL
    }

    fun grass(c: Canvas, w: Float, u: Float, dk: Float, wind: Float, gw: Float, t: Float, hf: (Float) -> Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = max(1f, 0.45f * u)
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = mixC(rgb(74, 150, 62), rgb(26, 56, 40), dk)
        val p = Path()
        var x = 3f
        while (x < w) {
            val y = hf(x) + 2.2f * u
            val h = (2.4f + ((x * 7f).toInt() % 5) * 0.5f) * u
            val sw = wind * (0.25f + gw * 0.9f) * 2.2f * u + sin(t * 3f + x) * wind * 0.4f * u
            p.moveTo(x, y); p.quadTo(x + sw * 0.3f, y - h * 0.6f, x + sw, y - h)
            x += 9f * (w / 400f)
        }
        c.drawPath(p, paint)
        paint.style = Paint.Style.FILL
    }

    fun fireflies(c: Canvas, w: Float, h: Float, u: Float, night: Float, cloud: Float, rain: Float, t: Float, hf: (Float) -> Float) {
        val a = night * clamp01(1f - cloud * 1.4f) * clamp01(1f - rain * 3f)
        if (a < 0.05f) return
        paint.style = Paint.Style.FILL
        for (i in 0 until 14) {
            val x = (fx[i] + sin(t * fs[i] + fp[i]) * 0.04f) * w
            val y = hf(x) + (fy[i] - 0.78f) * h * 0.35f + kotlin.math.cos(t * fs[i] * 1.3f + fp[i]) * h * 0.015f
            val b = 0.5f + 0.5f * sin(t * 2.2f + fp[i])
            paint.color = Color.argb((255f * a * b * 0.9f).toInt(), 210, 255, 120)
            c.drawCircle(x, y, max(1.2f, 0.35f * u), paint)
            paint.color = Color.argb((255f * a * b * 0.18f).toInt(), 210, 255, 120)
            c.drawCircle(x, y, 1.6f * u, paint)
        }
    }

    fun meteor(c: Canvas, w: Float, h: Float, night: Float, cloud: Float, dt: Float) {
        if (night * clamp01(1f - cloud * 1.4f) < 0.5f) { metOn = false; return }
        metWait -= dt
        if (!metOn && metWait <= 0f) {
            metOn = true; metT = 0f
            metX = w * (0.15f + Random.nextFloat() * 0.6f)
            metY = h * (0.04f + Random.nextFloat() * 0.18f)
            metWait = 18f + Random.nextFloat() * 30f
        }
        if (!metOn) return
        metT += dt
        val p = metT / 0.9f
        if (p >= 1f) { metOn = false; return }
        val len = w * 0.16f
        val x = metX + len * p
        val y = metY + len * 0.45f * p
        paint.shader = LinearGradient(
            x - len * 0.35f, y - len * 0.16f, x, y,
            Color.argb(0, 255, 255, 255), Color.argb((255f * 0.9f * (1f - p)).toInt(), 255, 255, 255),
            Shader.TileMode.CLAMP
        )
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.6f * (w / 400f)
        c.drawLine(x - len * 0.35f, y - len * 0.16f, x, y, paint)
        paint.shader = null
        paint.style = Paint.Style.FILL
    }

    // ---------- bichos ----------
    private fun spawn() {
        var k = Random.nextInt(2)
        if (k == lastKind) k = 1 - k
        lastKind = k
        val n = 1 + Random.nextInt(2)
        val dir = if (Random.nextBoolean()) 1f else -1f
        herd = Herd(k, dir, if (dir > 0f) -0.08f else 1.08f, speeds[k] * (0.85f + Random.nextFloat() * 0.3f), n,
            FloatArray(n) { Random.nextFloat() * 6f })
    }

    fun herd(c: Canvas, w: Float, h: Float, u: Float, dk: Float, night: Float, rain: Float, t: Float, dt: Float, hf: (Float) -> Float) {
        val cur0 = herd
        if (cur0 != null) {
            cur0.x += cur0.dir * cur0.v * dt
            val mo = (cur0.n - 1) * gap * u
            if ((cur0.dir > 0f && cur0.x * w - mo > w + 10f * u) || (cur0.dir < 0f && cur0.x * w + mo < -10f * u)) {
                herd = null
                herdWait = 4f + Random.nextFloat() * 8f
            }
        } else {
            herdWait -= dt
            if (herdWait <= 0f) spawn()
        }
        val cur = herd ?: return
        val va = clamp01((1f - night) * clamp01(1f - rain * 2.5f))
        if (va < 0.02f) return
        val layer = c.saveLayerAlpha(0f, 0f, w, h, (255f * va).toInt())
        for (i in 0 until cur.n) {
            val px = cur.x * w - cur.dir * i * gap * u
            val py = hf(px) + 11f * u
            val sg = sin(t * gaits[cur.kind] + cur.ph[i])
            c.save()
            c.translate(px, py)
            c.scale(cur.dir * scales[cur.kind], scales[cur.kind])
            if (cur.kind == 0) horse(c, u, dk, sg) else ox(c, u, dk, sg)
            c.restore()
        }
        c.restoreToCount(layer)
    }

    private fun oval(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float) {
        c.drawOval(RectF(cx - rx, cy - ry, cx + rx, cy + ry), paint)
    }

    private fun legs(c: Canvas, xs: FloatArray, top: Float, sg: Float, wd: Float, col: Int, u: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = wd
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = col
        for (i in xs.indices) {
            val s = (if (i % 2 == 1) -1f else 1f) * sg
            c.drawLine(xs[i] * u, -top * u, xs[i] * u + s * 1.2f * u, 0f, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun horse(c: Canvas, u: Float, dk: Float, sg: Float) {
        val body = mixC(rgb(138, 90, 56), rgb(58, 46, 44), dk)
        val dark = mixC(rgb(50, 34, 26), rgb(30, 26, 30), dk)
        legs(c, floatArrayOf(-3.8f, -2.4f, 2.6f, 4f), 5f, sg, 0.9f * u, dark, u)
        paint.color = body
        oval(c, 0f, -7f * u, 5.6f * u, 2.7f * u)
        val neck = Path()
        neck.moveTo(3.4f * u, -8.4f * u); neck.lineTo(5.6f * u, -12.6f * u)
        neck.lineTo(7.6f * u, -11.6f * u); neck.lineTo(5.4f * u, -6.2f * u); neck.close()
        c.drawPath(neck, paint)
        c.save()
        c.rotate(0.45f * 180f / PI.toFloat(), 8.2f * u, -11.3f * u)
        oval(c, 8.2f * u, -11.3f * u, 2.3f * u, 1.1f * u)
        c.restore()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 0.9f * u
        paint.color = dark
        val m = Path()
        m.moveTo(3.8f * u, -9f * u); m.lineTo(5.8f * u, -12.6f * u)
        m.moveTo(-5.4f * u, -8f * u); m.quadTo(-8f * u, -6.5f * u, -7.4f * u, -3.6f * u)
        c.drawPath(m, paint)
        paint.style = Paint.Style.FILL
    }

    private fun ox(c: Canvas, u: Float, dk: Float, sg: Float) {
        val b = mixC(rgb(126, 84, 58), rgb(56, 44, 42), dk)
        val l = mixC(rgb(226, 214, 196), rgb(110, 112, 122), dk)
        val m = mixC(rgb(60, 40, 32), rgb(30, 26, 30), dk)
        legs(c, floatArrayOf(-4f, -2.6f, 2.6f, 4f), 4f, sg, 1.1f * u, m, u)
        paint.color = b
        oval(c, 0f, -6.2f * u, 6.2f * u, 3.2f * u)
        paint.color = l
        oval(c, -1.5f * u, -5f * u, 2.2f * u, 1.4f * u)
        paint.color = b
        oval(c, 7f * u, -6.4f * u, 2.4f * u, 1.9f * u)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 0.6f * u
        paint.color = l
        c.drawLine(6.6f * u, -8f * u, 6.2f * u, -9.6f * u, paint)
        c.drawLine(8f * u, -8f * u, 8.8f * u, -9.4f * u, paint)
        paint.strokeWidth = 0.7f * u
        paint.color = m
        val tail = Path()
        tail.moveTo(-6.1f * u, -7.2f * u); tail.quadTo(-8f * u, -5.5f * u, -7.6f * u, -3f * u)
        c.drawPath(tail, paint)
        paint.style = Paint.Style.FILL
    }
}
