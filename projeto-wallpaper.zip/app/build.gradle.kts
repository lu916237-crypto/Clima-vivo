plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.clima.vivo"
    compileSdk = 34

    defaultConfig {
        applicationId = "br.clima.vivo"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1-teste"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
